# بنك اسئلة الاحياء توجيهي 2026 — مشروع Android

هذا مشروع تطبيق Android متقدم من نوع WebView يعرض:
https://life-science-question-atlas.lovable.app/

## المزايا
- تطبيق مستقل باسم بنك اسئلة الاحياء توجيهي 2026.
- أيقونة مخصصة بطابع كتاب وDNA.
- شريط تقدم أثناء تحميل الموقع.
- JavaScript وDOM Storage للحفاظ على عمل تطبيق الويب وتسجيل الجلسات.
- زر الرجوع يتنقل داخل صفحات الموقع.
- تمرير روابط المواقع الخارجية إلى المتصفح.
- دعم تنزيل الملفات عبر Download Manager.
- HTTPS فقط، ولا يسمح بتحميل محتوى HTTP غير المشفر.

## بناء APK
يتطلب Android SDK وJava 17 وGradle 8.9 أو Android Studio حديثاً.

1. افتح المشروع في Android Studio.
2. انتظر اكتمال Gradle Sync.
3. من القائمة Build اختر Build Bundle(s) / APK(s) ثم Build APK(s).
4. ملف APK الناتج سيكون في:
   `app/build/outputs/apk/debug/app-debug.apk`

## البناء السحابي عبر GitHub Actions
ارفع محتويات هذا المجلد إلى مستودع GitHub جديد على الفرع `main`.
سيعمل الملف `.github/workflows/build-apk.yml` تلقائياً، أو شغّل workflow يدوياً من تبويب Actions.
بعد اكتمال البناء، نزّل artifact باسم `biology-question-atlas-apk`.

## ملاحظات قبل النشر
- هذه نسخة WebView وليست نسخة أصلية Offline؛ تحتاج اتصالاً بالإنترنت.
- يلزم اختبار نماذج تسجيل الدخول والرفع والتنزيل بالموقع على أجهزة فعلية.
- إذا أضاف الموقع نطاقات خارجية أساسية أو تدفق OAuth، قد نحتاج إلى إدراج النطاقات الموثوقة في سياسة التنقل.
- ملف APK الناتج من GitHub Actions هو Debug APK للتجربة والتثبيت. للنشر العام يوصى بإنشاء مفتاح توقيع خاص وبناء Release APK موقّع.
