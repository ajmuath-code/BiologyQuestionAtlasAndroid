plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "jo.edu.biologyatlas"
    compileSdk = 35
    defaultConfig {
        applicationId = "jo.edu.biologyatlas"
        minSdk = 23
        targetSdk = 35
        versionCode = 1
        versionName = "1.0.0"
    }
}
